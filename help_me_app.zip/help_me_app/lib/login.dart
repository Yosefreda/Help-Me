import 'package:help_me/dashboard.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/sign.dart';
import 'package:help_me/constant/APIs.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/widgets.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  TextEditingController phone = TextEditingController();

  Future<void> LoginClient() async
  {

    if (phone.text.isNotEmpty) 
    {
      try 
      {

        var validate = await http.post(
          Uri.parse(ApisConnect.checkPhoneNumberApi),
          body: {
            "phone" : phone.text
          }
        );

        var response1 = jsonDecode(validate.body);

        if (response1["exists"] == true) 
        {
          var login = await http.post(
          Uri.parse(ApisConnect.loginApi),
            body: {
              "phone": phone.text,
            },
          );

          var response2 = jsonDecode(login.body);

          if (response2["check"] == true) 
          {
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => DashboardScreen(userData: response2["userData"])));

            Fluttertoast.showToast(msg: 'Logined Successfully'); 
          }
          else if(response2["check"] == false)
          {
            Fluttertoast.showToast(msg: 'You Are blocked, If you have any error call Techneical Support');
          }

        }
        else
        {
          Fluttertoast.showToast(msg: 'This Number not signed, sign up first.');
        }

      } 
      catch (e) 
      {
        Fluttertoast.showToast(msg: 'Error: $e');
      }       
    }
    else
    {
      Fluttertoast.showToast(msg: 'Fill The field first');
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),

      body: Column(

        children: 
        [

          SizedBox(height: FSizes.btwSections),

          MainLogo(),

          SizedBox(height: FSizes.btwSections),
          SizedBox(height: FSizes.btwInputs),

          InternationalPhoneNumberInput(controller: phone),

          SizedBox(height: FSizes.btwSections),

          ElevatedButton(
            onPressed: (){
              LoginClient();
            }, 
            child: Text(
              'Login',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: FSizes.smallFont
              ),
            )
          ),

          SizedBox(height: FSizes.btwInputs),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,

            children: [
              Text(
                'Don\'t Have Account !'
              ),

              TextButton(
                onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (context)=> SignScreen())), 
                child: Text(
                  'Sign Up'
                ) 
              )
            ],
          ),

          SizedBox(height: 10),
        ]
      )
    );
  }
}