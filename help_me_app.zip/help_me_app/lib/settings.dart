import 'package:help_me/editPhone.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:help_me/sign.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/buttons.dart';

class SettingsScreen extends StatefulWidget {

  final String userID;

  const SettingsScreen({
    super.key,
    required this.userID
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),

      body: Column(
        children: 
        [
          SizedBox(height: FSizes.btwInputs),

          MainLogo(),

          SizedBox(height: FSizes.btwSections),
          SizedBox(height: FSizes.btwSections),


          SettingsButtons(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => EditPhoneNumberScreen(userID: widget.userID))),
            icon: Icon(Icons.edit), 
            text: S.of(context).Edit_Phone_Number
          ),

          SizedBox(height: FSizes.btwInputs),

          SettingsButtons(
            onPressed: (){
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => SignScreen()),
                (Route<dynamic> route) => false,
              );
            },
            icon: Icon(Icons.logout_sharp),
            text: S.of(context).logout
          ),

          SizedBox(height: FSizes.btwSections),

        ]
      )
    );
  }
}