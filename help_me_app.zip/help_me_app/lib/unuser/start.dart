import 'package:help_me/generated/l10n.dart';
import 'package:help_me/unuser/postsUnuser.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/colors.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/login.dart';
import 'package:help_me/sign.dart';

class HomeUnUsers extends StatefulWidget {
  const HomeUnUsers({super.key});

  @override
  State<HomeUnUsers> createState() => _HomeUnUsersState();
}

class _HomeUnUsersState extends State<HomeUnUsers> {

  TextEditingController search = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(),

      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: 
          [
            UserAccountsDrawerHeader(
              accountName: Text(
                S.of(context).no_sign
              ), 
              accountEmail: Text(
                S.of(context).enter_option
              ),
              currentAccountPicture: CircleAvatar(
                child: ClipOval(
                  child: Icon(
                    Icons.person,
                    size: 40
                  )
                )
              ),
              decoration: BoxDecoration(
                color: FColors.primary
              )
            ),

            ListTile(
              leading: Icon(Icons.person_2_outlined),
              title: Text(S.of(context).sign),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => SignScreen()));
              } 
            ),

            Divider(),

            ListTile(
              leading: Icon(Icons.login),
              title: Text(S.of(context).login),
              onTap: (){ 
                Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
              }
            ),

          ]
        )
      ),

      body: SingleChildScrollView(
        child: Column(
        
          children: 
          [
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: SearchInput(controller: search) 
            ),
        
            SizedBox(height: FSizes.btwSections),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  S.of(context).to_publish,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                ),
                TextButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SignScreen()));
                  }, 
                  child: Text(
                    S.of(context).sign,
                    style: TextStyle(
                      fontWeight: FontWeight.bold
                    )
                  )
                ),
              ],
            ),
        
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
        
              children: [
                Text(
                  S.of(context).what,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                ),
        
                TextButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => PostsUnuserScreen()));
                  }, 
                  child: Text(
                    S.of(context).see_all,
                    style: TextStyle(
                      fontWeight: FontWeight.bold
                    )
                  )
                )
              ],
            ),
        
            SizedBox(height: FSizes.btwInputs),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,

              children: 
              [
                Text(
                  S.of(context).ads,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                )
              ]
            ),

            Column(
              mainAxisAlignment: MainAxisAlignment.start,

              children: 
              [
                SizedBox(height: FSizes.btwSections),

                CarouselSlider(
                  items: [
                    Text('Advertise Here Now', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                    Text('Advertise Here Now', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                    Text('Advertise Here Now', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                  ], 
                  options: CarouselOptions(
                    height: 200,
                    viewportFraction: 0.8,
                    enlargeCenterPage: true,
                    autoPlay: true
                  )
                )

              ]
            ),

            SizedBox(height: FSizes.btwInputs),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
        
              children: [
                Text(
                  S.of(context).latest,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                ),
        
                TextButton(
                  onPressed: (){}, 
                  child: Text(
                    S.of(context).browse,
                    style: TextStyle(
                      fontWeight: FontWeight.bold
                    )
                  )
                )
              ],
            ),

            Column(
              children: 
              [
                CarouselSlider(
                  items: [
                    //'assets/user.png'
                  ],

                  // .map((imageUrl){
                  //   return Builder(
                  //     builder: (BuildContext context){
                  //       return Container(
                  //         child: Image.asset(
                  //           imageUrl,
                  //           fit: BoxFit.cover,
                  //         ),
                  //       );
                  //     },
                  //   );
                  // }).toList(),

                  
                  options: CarouselOptions(
                    height: 200,
                    viewportFraction: 0.8,
                    enlargeCenterPage: true,
                    autoPlay: true
                  )
                )
              ]
            )
    
          ]
        ),
      )





      // bottomNavigationBar: BottomNavigationBar(
      //   type: BottomNavigationBarType.fixed,
      //   items: [
      //     BottomNavigationBarItem(
      //       icon: Icon(Icons.home),
      //       label: 'Home',
      //     ),

      //     BottomNavigationBarItem(
      //       icon: Stack(
      //         children: [
      //           Positioned(
      //             bottom: 20,
      //             child: Container(
      //               width: 40,
      //               height: 40,
      //               decoration: BoxDecoration(
      //                 shape: BoxShape.circle,
      //                 color: Colors.blue,
      //               ),
      //               child: Icon(Icons.add, color: Colors.white),
      //             ),
      //           ),
      //         ],
      //       ),
      //       label: 'Add'
      //     ),

      //     BottomNavigationBarItem(
      //       icon: Icon(Icons.settings),
      //       label: 'Settings',
      //     )
      //   ]
      // )
        
    );
  }
}