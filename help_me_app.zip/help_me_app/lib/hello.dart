import 'package:help_me/sign.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/colors.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/generated/l10n.dart';


class HelloScreen extends StatefulWidget {

  final Function(Locale) onLocaleChange;
  
  const HelloScreen({super.key, required this.onLocaleChange});

  @override
  State<HelloScreen> createState() => _HelloScreenState();
}

class _HelloScreenState extends State<HelloScreen> {

  @override
  Widget build(BuildContext context) {

    bool? check = true;

    void Continuer(BuildContext)
    {
      if (check == true) 
      {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> SignScreen()));
      }
      else
      {
        print('Accept Our Privacy First!');
      }
    }

    return Scaffold(
      appBar: AppBar(),

      body: SingleChildScrollView(
        child: Column(
        
          mainAxisAlignment: MainAxisAlignment.center,
        
          children: 
          [
        
            SizedBox(height: FSizes.btwSections),
        
            MainLogo(),
        
            SizedBox(height: FSizes.btwInputs),
        
            Text(
              S.of(context).slang,
              style: TextStyle(
                color: FColors.primary,
                fontSize: FSizes.smallFont,
                fontWeight: FontWeight.w500
              )
            ),
        
            SizedBox(height: FSizes.btwSections),
            SizedBox(height: FSizes.btwSections),
        
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
        
                Checkbox(
                  value: check,
                  onChanged: (bool? value) {
                    setState(() {
                      check = value ?? false;
                    });
                  },
                ),
        
                Text(
                  S.of(context).policy,
                  style: TextStyle(
                    color: FColors.primary,
                    fontSize: 15,
                    fontWeight: FontWeight.w400
                  )
                ),
        
              ]
            ),
        
            SizedBox(height: FSizes.btwSections),
            SizedBox(height: FSizes.btwSections),
        
            ElevatedButton(
              onPressed: (){
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => SignScreen()));
              }, 
              child: Text(
                S.of(context).resume,
                style: TextStyle(
                  fontSize: FSizes.medFont
                ),
              )
            ),
        
            SizedBox(height: FSizes.btwSections),
            SizedBox(height: FSizes.btwSections),
        
            TextButton(
              onPressed: () {
                widget.onLocaleChange(Locale('en', ''));
              },            
        
              child: Text('English')
            ),
        
            TextButton(
              onPressed: () {
                widget.onLocaleChange(Locale('ar', ''));
              },                
        
              child: Text('عربي')
            )
        
          ]
        ),
      )
    );
  }
  
}