import 'package:help_me/constant/APIs.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/widgets.dart';


class ContactScreen extends StatefulWidget {

  final String userID;

  const ContactScreen({
    super.key,
    required this.userID
  });

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {

  TextEditingController subject = TextEditingController();
  TextEditingController topic = TextEditingController();

  Future<void> InsertProblem() async
  {
    if (subject.text.isNotEmpty && topic.text.isNotEmpty) 
    {
      try 
      {
        var send = await http.post(
          Uri.parse(ApisConnect.problemInsert),
          body: 
          {
            "subject" : subject.text,
            "topic" : topic.text,
            "client" : widget.userID
          }
        );

        var response = jsonDecode(send.body);

        if (response["problem"] == true) 
        {
          Fluttertoast.showToast(msg: 'You are send your problem and suggest, Thank You');

          subject.clear();
          topic.clear();
        } 
        else 
        {
          Fluttertoast.showToast(msg: 'May be had error, Please try again');
        }
      } 
      catch (e) 
      {
        Fluttertoast.showToast(msg: 'Error $e');
      }  
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),

      body: SingleChildScrollView(
        child: Column(
          children: 
          [
            MainLogo(),
        
            SizedBox(height: FSizes.btwSections),
        
            Text(
              S.of(context).sug,
              style: TextStyle(
                fontSize: FSizes.medFont,
                fontWeight: FontWeight.bold
              )
            ),
        
            SizedBox(height: FSizes.btwSections),
        
            MainInput(secure: false, text: S.of(context).subject, controller: subject),
        
            SizedBox(height: FSizes.btwSections),
        
            MainInput(secure: false, text: S.of(context).topic, controller: topic),
        
            SizedBox(height: FSizes.btwSections),
        
            ElevatedButton(
              onPressed: (){
                InsertProblem();
              }, 
              child: Text(
                S.of(context).send,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20
                )
              )
            )
            
          ]
        ),
      )
    );
  }
}