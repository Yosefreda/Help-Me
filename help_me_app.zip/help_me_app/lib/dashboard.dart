import 'package:help_me/generated/l10n.dart';
import 'package:help_me/posts/posts.dart';
import 'package:help_me/types.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/colors.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/posts/addPost.dart';
import 'package:help_me/posts/myPosts.dart';
import 'package:help_me/contact.dart';
import 'package:help_me/settings.dart';
// import 'dart:async';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter/widgets.dart';

class DashboardScreen extends StatefulWidget {

  final userData;

  const DashboardScreen({
    super.key,
    required this.userData
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  TextEditingController search = TextEditingController();

  @override
  Widget build(BuildContext context) {

    String clientID = widget.userData["user_id"];
    String clientName = widget.userData["name"];
    String clientPhone = widget.userData["phone"];

    return Scaffold(

      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: 
          [
            UserAccountsDrawerHeader(
              accountName: Text('Hello ${clientName}'),
              accountEmail: Text('${clientPhone}'),
              currentAccountPicture: CircleAvatar(
                child: ClipOval(
                  child: Icon(
                    Icons.person,
                    size: 40
                  )
                )
              ),
              decoration: BoxDecoration(
                color: FColors.primary
              ),
            ),

            ListTile(
              leading: Icon(Icons.window_outlined),

              title: Text(
                S.of(context).my_things,
                style: TextStyle(
                  fontWeight: FontWeight.bold
                )
              ),

              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => MyPostsScreen(userID: clientID)))
            ),

            ListTile(
              leading: Icon(Icons.search),

              title: Text(
                S.of(context).search,
                style: TextStyle(
                  fontWeight: FontWeight.bold
                )
              ),
              
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => TypesScreen()))
            ),


            ListTile(
              leading: Icon(Icons.data_saver_on),

              title: Text(
                S.of(context).new_thing,
                style: TextStyle(
                  fontWeight: FontWeight.bold
                )
              ),
              
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => ThingUploadScreen(userID: clientID))),
            ),


            Divider(color: Colors.grey),

            ListTile(
              leading: Icon(Icons.settings),

              title: Text(
                S.of(context).settings,
                style: TextStyle(
                  fontWeight: FontWeight.bold
                )
              ),
              
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsScreen(userID: clientID)))
            ),

            ListTile(
              leading: Icon(Icons.chat_bubble_outline_sharp),

              title: Text(
                S.of(context).contact,
                style: TextStyle(
                  fontWeight: FontWeight.bold
                )
              ),
              
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => ContactScreen(userID: clientID)))
            )

          ]
        )
      ),
      
      appBar: AppBar(),

      body: SingleChildScrollView(
        child: Column(
          children: 
          [
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: SearchInput(controller: search) 
            ),

            SizedBox(height: FSizes.btwInputs),     

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
        
              children: [
                Text(
                  S.of(context).what,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                ),
        
                TextButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => PostsScreen()));
                  }, 
                  child: Text(
                    S.of(context).see_all,
                    style: TextStyle(
                      fontWeight: FontWeight.bold
                    )
                  )
                )
              ],
            ),
        
            SizedBox(height: FSizes.btwInputs),     
               
            SizedBox(height: FSizes.btwInputs),


            Row(
              mainAxisAlignment: MainAxisAlignment.center,

              children: 
              [
                Text(
                  S.of(context).ads,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                )
              ]
            ),

            Column(
              mainAxisAlignment: MainAxisAlignment.start,

              children: 
              [
                SizedBox(height: FSizes.btwSections),

                CarouselSlider(
                  items: [
                    Text('Advertise Here Now', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                    Text('Advertise Here Now', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                    Text('Advertise Here Now', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                  ], 
                  
                  options: CarouselOptions(
                    height: 200,
                    viewportFraction: 0.8,
                    enlargeCenterPage: true,
                    autoPlay: true
                  )
                )

              ]
            ),

            SizedBox(height: FSizes.btwInputs),
          ]
        ),
      )
    );
  }
}