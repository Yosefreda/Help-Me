// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Help Me`
  String get logo {
    return Intl.message(
      'Help Me',
      name: 'logo',
      desc: '',
      args: [],
    );
  }

  /// `POWERED BY CU`
  String get company {
    return Intl.message(
      'POWERED BY CU',
      name: 'company',
      desc: '',
      args: [],
    );
  }

  /// `If You Used Our App, You Are agree on policies`
  String get policy {
    return Intl.message(
      'If You Used Our App, You Are agree on policies',
      name: 'policy',
      desc: '',
      args: [],
    );
  }

  /// `continue`
  String get resume {
    return Intl.message(
      'continue',
      name: 'resume',
      desc: '',
      args: [],
    );
  }

  /// `If you Lost, You Will Find`
  String get slang {
    return Intl.message(
      'If you Lost, You Will Find',
      name: 'slang',
      desc: '',
      args: [],
    );
  }

  /// `Search Here`
  String get search {
    return Intl.message(
      'Search Here',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `Phone Number`
  String get phone {
    return Intl.message(
      'Phone Number',
      name: 'phone',
      desc: '',
      args: [],
    );
  }

  /// `Select Type`
  String get type {
    return Intl.message(
      'Select Type',
      name: 'type',
      desc: '',
      args: [],
    );
  }

  /// `Missed`
  String get missed {
    return Intl.message(
      'Missed',
      name: 'missed',
      desc: '',
      args: [],
    );
  }

  /// `Found`
  String get found {
    return Intl.message(
      'Found',
      name: 'found',
      desc: '',
      args: [],
    );
  }

  /// `Upload `
  String get upload {
    return Intl.message(
      'Upload ',
      name: 'upload',
      desc: '',
      args: [],
    );
  }

  /// `Post`
  String get post {
    return Intl.message(
      'Post',
      name: 'post',
      desc: '',
      args: [],
    );
  }

  /// `Name`
  String get name {
    return Intl.message(
      'Name',
      name: 'name',
      desc: '',
      args: [],
    );
  }

  /// `Description`
  String get description {
    return Intl.message(
      'Description',
      name: 'description',
      desc: '',
      args: [],
    );
  }

  /// `More marks (Optional)`
  String get location {
    return Intl.message(
      'More marks (Optional)',
      name: 'location',
      desc: '',
      args: [],
    );
  }

  /// `Where`
  String get where {
    return Intl.message(
      'Where',
      name: 'where',
      desc: '',
      args: [],
    );
  }

  /// `Date`
  String get date {
    return Intl.message(
      'Date',
      name: 'date',
      desc: '',
      args: [],
    );
  }

  /// `Submit`
  String get submit {
    return Intl.message(
      'Submit',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  /// `Thing Name`
  String get thing_name {
    return Intl.message(
      'Thing Name',
      name: 'thing_name',
      desc: '',
      args: [],
    );
  }

  /// `Thing Type`
  String get thing_type {
    return Intl.message(
      'Thing Type',
      name: 'thing_type',
      desc: '',
      args: [],
    );
  }

  /// `Published`
  String get published {
    return Intl.message(
      'Published',
      name: 'published',
      desc: '',
      args: [],
    );
  }

  /// `Pending`
  String get pending {
    return Intl.message(
      'Pending',
      name: 'pending',
      desc: '',
      args: [],
    );
  }

  /// `Refused`
  String get refused {
    return Intl.message(
      'Refused',
      name: 'refused',
      desc: '',
      args: [],
    );
  }

  /// `Contact Us`
  String get contact {
    return Intl.message(
      'Contact Us',
      name: 'contact',
      desc: '',
      args: [],
    );
  }

  /// `Log Out`
  String get logout {
    return Intl.message(
      'Log Out',
      name: 'logout',
      desc: '',
      args: [],
    );
  }

  /// `Sign Up !`
  String get sign {
    return Intl.message(
      'Sign Up !',
      name: 'sign',
      desc: '',
      args: [],
    );
  }

  /// `Already Have Account !`
  String get account {
    return Intl.message(
      'Already Have Account !',
      name: 'account',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Take A Tour in The App`
  String get tour {
    return Intl.message(
      'Take A Tour in The App',
      name: 'tour',
      desc: '',
      args: [],
    );
  }

  /// `'Go Now!`
  String get go {
    return Intl.message(
      '\'Go Now!',
      name: 'go',
      desc: '',
      args: [],
    );
  }

  /// `To Publish Posts Sign Up >`
  String get to_publish {
    return Intl.message(
      'To Publish Posts Sign Up >',
      name: 'to_publish',
      desc: '',
      args: [],
    );
  }

  /// `What You Lost Or Found?`
  String get what {
    return Intl.message(
      'What You Lost Or Found?',
      name: 'what',
      desc: '',
      args: [],
    );
  }

  /// `See All`
  String get see_all {
    return Intl.message(
      'See All',
      name: 'see_all',
      desc: '',
      args: [],
    );
  }

  /// `Person`
  String get person {
    return Intl.message(
      'Person',
      name: 'person',
      desc: '',
      args: [],
    );
  }

  /// `Car`
  String get car {
    return Intl.message(
      'Car',
      name: 'car',
      desc: '',
      args: [],
    );
  }

  /// `Electronic`
  String get electronic {
    return Intl.message(
      'Electronic',
      name: 'electronic',
      desc: '',
      args: [],
    );
  }

  /// `Keys`
  String get key {
    return Intl.message(
      'Keys',
      name: 'key',
      desc: '',
      args: [],
    );
  }

  /// `Watch`
  String get watch {
    return Intl.message(
      'Watch',
      name: 'watch',
      desc: '',
      args: [],
    );
  }

  /// `Jewellry`
  String get jewellry {
    return Intl.message(
      'Jewellry',
      name: 'jewellry',
      desc: '',
      args: [],
    );
  }

  /// `Document`
  String get document {
    return Intl.message(
      'Document',
      name: 'document',
      desc: '',
      args: [],
    );
  }

  /// `Other`
  String get other {
    return Intl.message(
      'Other',
      name: 'other',
      desc: '',
      args: [],
    );
  }

  /// `Ads`
  String get ads {
    return Intl.message(
      'Ads',
      name: 'ads',
      desc: '',
      args: [],
    );
  }

  /// `Latest Things`
  String get latest {
    return Intl.message(
      'Latest Things',
      name: 'latest',
      desc: '',
      args: [],
    );
  }

  /// `Browse Posts`
  String get browse {
    return Intl.message(
      'Browse Posts',
      name: 'browse',
      desc: '',
      args: [],
    );
  }

  /// `You Are Not Signed!`
  String get no_sign {
    return Intl.message(
      'You Are Not Signed!',
      name: 'no_sign',
      desc: '',
      args: [],
    );
  }

  /// `Sign Up Or Login First`
  String get enter_option {
    return Intl.message(
      'Sign Up Or Login First',
      name: 'enter_option',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: '',
      args: [],
    );
  }

  /// `New Thing`
  String get new_thing {
    return Intl.message(
      'New Thing',
      name: 'new_thing',
      desc: '',
      args: [],
    );
  }

  /// `My Things`
  String get my_things {
    return Intl.message(
      'My Things',
      name: 'my_things',
      desc: '',
      args: [],
    );
  }

  /// `Subject`
  String get subject {
    return Intl.message(
      'Subject',
      name: 'subject',
      desc: '',
      args: [],
    );
  }

  /// `Topic`
  String get topic {
    return Intl.message(
      'Topic',
      name: 'topic',
      desc: '',
      args: [],
    );
  }

  /// `Send`
  String get send {
    return Intl.message(
      'Send',
      name: 'send',
      desc: '',
      args: [],
    );
  }

  /// `Suggesstion & Problems`
  String get sug {
    return Intl.message(
      'Suggesstion & Problems',
      name: 'sug',
      desc: '',
      args: [],
    );
  }

  /// `Edit Phone Number`
  String get Edit_Phone_Number {
    return Intl.message(
      'Edit Phone Number',
      name: 'Edit_Phone_Number',
      desc: '',
      args: [],
    );
  }

  /// `Filter`
  String get filter {
    return Intl.message(
      'Filter',
      name: 'filter',
      desc: '',
      args: [],
    );
  }

  /// `See Results`
  String get see {
    return Intl.message(
      'See Results',
      name: 'see',
      desc: '',
      args: [],
    );
  }

  /// `All`
  String get all {
    return Intl.message(
      'All',
      name: 'all',
      desc: '',
      args: [],
    );
  }

  /// `Select Type`
  String get select {
    return Intl.message(
      'Select Type',
      name: 'select',
      desc: '',
      args: [],
    );
  }

  /// `New Phone Number`
  String get new_phone {
    return Intl.message(
      'New Phone Number',
      name: 'new_phone',
      desc: '',
      args: [],
    );
  }

  /// `Missed Or Found`
  String get or {
    return Intl.message(
      'Missed Or Found',
      name: 'or',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
