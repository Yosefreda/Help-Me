// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ar locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ar';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "Edit_Phone_Number":
            MessageLookupByLibrary.simpleMessage("تعديل رقم الهاتف"),
        "account": MessageLookupByLibrary.simpleMessage("بالفعل لدي حساب !"),
        "ads": MessageLookupByLibrary.simpleMessage("اعلانات"),
        "all": MessageLookupByLibrary.simpleMessage("الجميع"),
        "browse": MessageLookupByLibrary.simpleMessage("تصفح الاشياء"),
        "car": MessageLookupByLibrary.simpleMessage("سيارة"),
        "company": MessageLookupByLibrary.simpleMessage(" تم تشغيله بواسطة CU"),
        "contact": MessageLookupByLibrary.simpleMessage("تواصل معنا"),
        "date": MessageLookupByLibrary.simpleMessage("التاريخ"),
        "description": MessageLookupByLibrary.simpleMessage("الوصف"),
        "document": MessageLookupByLibrary.simpleMessage("مستند"),
        "electronic": MessageLookupByLibrary.simpleMessage("الكترونيات"),
        "enter_option":
            MessageLookupByLibrary.simpleMessage("سجل الدخول او الاشتراك اولا"),
        "filter": MessageLookupByLibrary.simpleMessage("تصنيفات"),
        "found": MessageLookupByLibrary.simpleMessage("موجود"),
        "go": MessageLookupByLibrary.simpleMessage("هيا الآن"),
        "jewellry": MessageLookupByLibrary.simpleMessage("مجوهرات"),
        "key": MessageLookupByLibrary.simpleMessage("مفاتيح"),
        "latest": MessageLookupByLibrary.simpleMessage("احدث الاشياء"),
        "location":
            MessageLookupByLibrary.simpleMessage("علامات اضافية (ان وجدت)"),
        "login": MessageLookupByLibrary.simpleMessage("دخول"),
        "logo": MessageLookupByLibrary.simpleMessage("ساعدني"),
        "logout": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
        "missed": MessageLookupByLibrary.simpleMessage("مفقود"),
        "my_things": MessageLookupByLibrary.simpleMessage("أشيائي"),
        "name": MessageLookupByLibrary.simpleMessage("الاسم"),
        "new_phone": MessageLookupByLibrary.simpleMessage("رقم هاتفك الجديد"),
        "new_thing": MessageLookupByLibrary.simpleMessage("نشر شئ جديد"),
        "no_sign": MessageLookupByLibrary.simpleMessage("انت لست مسجل لدينا"),
        "or": MessageLookupByLibrary.simpleMessage("مفقود او موجود"),
        "other": MessageLookupByLibrary.simpleMessage("آخرى"),
        "pending": MessageLookupByLibrary.simpleMessage("معلق"),
        "person": MessageLookupByLibrary.simpleMessage("شخص"),
        "phone": MessageLookupByLibrary.simpleMessage("رقم الهاتف"),
        "policy": MessageLookupByLibrary.simpleMessage(
            "اذا قمت بتسجيل الدخول، فانت توافق على سياسة البرنامج"),
        "post": MessageLookupByLibrary.simpleMessage("منشور"),
        "published": MessageLookupByLibrary.simpleMessage("تم نشره"),
        "refused": MessageLookupByLibrary.simpleMessage("مرفوض"),
        "resume": MessageLookupByLibrary.simpleMessage("استمرار"),
        "search": MessageLookupByLibrary.simpleMessage("ابحث هنا"),
        "see": MessageLookupByLibrary.simpleMessage("رؤية جميع النتائج"),
        "see_all": MessageLookupByLibrary.simpleMessage("مشاهدة الكل"),
        "select": MessageLookupByLibrary.simpleMessage("اختار نوع"),
        "send": MessageLookupByLibrary.simpleMessage("إرسال"),
        "settings": MessageLookupByLibrary.simpleMessage("الإعدادات"),
        "sign": MessageLookupByLibrary.simpleMessage("اشترك الان"),
        "slang":
            MessageLookupByLibrary.simpleMessage("لو حاجة ضاعت منك هتلاقيها"),
        "subject": MessageLookupByLibrary.simpleMessage("العنوان"),
        "submit": MessageLookupByLibrary.simpleMessage("تأكيد"),
        "sug": MessageLookupByLibrary.simpleMessage("للشكاوى والاقتراحات"),
        "thing_name": MessageLookupByLibrary.simpleMessage("اسم الشئ"),
        "thing_type": MessageLookupByLibrary.simpleMessage("نوع الشئ"),
        "to_publish": MessageLookupByLibrary.simpleMessage(
            "سجل الدخول الآن لتتمكن من نشر منشورات"),
        "topic": MessageLookupByLibrary.simpleMessage("الموضوع"),
        "tour":
            MessageLookupByLibrary.simpleMessage("خذ جولة تصفح في البرنامج"),
        "type": MessageLookupByLibrary.simpleMessage("اختار النوع"),
        "upload": MessageLookupByLibrary.simpleMessage("رفع "),
        "watch": MessageLookupByLibrary.simpleMessage("ساعة"),
        "what": MessageLookupByLibrary.simpleMessage("ماذا فقدت او وجدت ؟"),
        "where": MessageLookupByLibrary.simpleMessage("اين وجدت او فقدت")
      };
}
