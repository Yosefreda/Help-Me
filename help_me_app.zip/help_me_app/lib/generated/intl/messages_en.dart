// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "Edit_Phone_Number":
            MessageLookupByLibrary.simpleMessage("Edit Phone Number"),
        "account":
            MessageLookupByLibrary.simpleMessage("Already Have Account !"),
        "ads": MessageLookupByLibrary.simpleMessage("Ads"),
        "all": MessageLookupByLibrary.simpleMessage("All"),
        "browse": MessageLookupByLibrary.simpleMessage("Browse Posts"),
        "car": MessageLookupByLibrary.simpleMessage("Car"),
        "company": MessageLookupByLibrary.simpleMessage("POWERED BY CU"),
        "contact": MessageLookupByLibrary.simpleMessage("Contact Us"),
        "date": MessageLookupByLibrary.simpleMessage("Date"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "document": MessageLookupByLibrary.simpleMessage("Document"),
        "electronic": MessageLookupByLibrary.simpleMessage("Electronic"),
        "enter_option":
            MessageLookupByLibrary.simpleMessage("Sign Up Or Login First"),
        "filter": MessageLookupByLibrary.simpleMessage("Filter"),
        "found": MessageLookupByLibrary.simpleMessage("Found"),
        "go": MessageLookupByLibrary.simpleMessage("\'Go Now!"),
        "jewellry": MessageLookupByLibrary.simpleMessage("Jewellry"),
        "key": MessageLookupByLibrary.simpleMessage("Keys"),
        "latest": MessageLookupByLibrary.simpleMessage("Latest Things"),
        "location":
            MessageLookupByLibrary.simpleMessage("More marks (Optional)"),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "logo": MessageLookupByLibrary.simpleMessage("Help Me"),
        "logout": MessageLookupByLibrary.simpleMessage("Log Out"),
        "missed": MessageLookupByLibrary.simpleMessage("Missed"),
        "my_things": MessageLookupByLibrary.simpleMessage("My Things"),
        "name": MessageLookupByLibrary.simpleMessage("Name"),
        "new_phone": MessageLookupByLibrary.simpleMessage("New Phone Number"),
        "new_thing": MessageLookupByLibrary.simpleMessage("New Thing"),
        "no_sign": MessageLookupByLibrary.simpleMessage("You Are Not Signed!"),
        "or": MessageLookupByLibrary.simpleMessage("Missed Or Found"),
        "other": MessageLookupByLibrary.simpleMessage("Other"),
        "pending": MessageLookupByLibrary.simpleMessage("Pending"),
        "person": MessageLookupByLibrary.simpleMessage("Person"),
        "phone": MessageLookupByLibrary.simpleMessage("Phone Number"),
        "policy": MessageLookupByLibrary.simpleMessage(
            "If You Used Our App, You Are agree on policies"),
        "post": MessageLookupByLibrary.simpleMessage("Post"),
        "published": MessageLookupByLibrary.simpleMessage("Published"),
        "refused": MessageLookupByLibrary.simpleMessage("Refused"),
        "resume": MessageLookupByLibrary.simpleMessage("continue"),
        "search": MessageLookupByLibrary.simpleMessage("Search Here"),
        "see": MessageLookupByLibrary.simpleMessage("See Results"),
        "see_all": MessageLookupByLibrary.simpleMessage("See All"),
        "select": MessageLookupByLibrary.simpleMessage("Select Type"),
        "send": MessageLookupByLibrary.simpleMessage("Send"),
        "settings": MessageLookupByLibrary.simpleMessage("Settings"),
        "sign": MessageLookupByLibrary.simpleMessage("Sign Up !"),
        "slang":
            MessageLookupByLibrary.simpleMessage("If you Lost, You Will Find"),
        "subject": MessageLookupByLibrary.simpleMessage("Subject"),
        "submit": MessageLookupByLibrary.simpleMessage("Submit"),
        "sug": MessageLookupByLibrary.simpleMessage("Suggesstion & Problems"),
        "thing_name": MessageLookupByLibrary.simpleMessage("Thing Name"),
        "thing_type": MessageLookupByLibrary.simpleMessage("Thing Type"),
        "to_publish":
            MessageLookupByLibrary.simpleMessage("To Publish Posts Sign Up >"),
        "topic": MessageLookupByLibrary.simpleMessage("Topic"),
        "tour": MessageLookupByLibrary.simpleMessage("Take A Tour in The App"),
        "type": MessageLookupByLibrary.simpleMessage("Select Type"),
        "upload": MessageLookupByLibrary.simpleMessage("Upload "),
        "watch": MessageLookupByLibrary.simpleMessage("Watch"),
        "what": MessageLookupByLibrary.simpleMessage("What You Lost Or Found?"),
        "where": MessageLookupByLibrary.simpleMessage("Where")
      };
}
