import 'package:help_me/generated/l10n.dart';
import 'package:help_me/constant/APIs.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/unuser/start.dart';
import 'package:help_me/login.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/widgets.dart';


class SignScreen extends StatefulWidget {
  const SignScreen({super.key});

  @override
  State<SignScreen> createState() => _SignScreenState();
}

class _SignScreenState extends State<SignScreen> {

  TextEditingController name = TextEditingController();
  TextEditingController phone = TextEditingController();

  Future<void> SignupClient() async 
  {
    if (name.text.isNotEmpty && phone.text.isNotEmpty) 
    {
      try {
        var res = await http.post(
          Uri.parse(ApisConnect.checkPhoneNumberApi),
          body: {
            "phone": phone.text,
          },
        );

        var response = jsonDecode(res.body);

        if (response["exists"] == true) 
        {
          Fluttertoast.showToast(msg: 'Phone number already exists, Login Direct');
        }
        else
        {

          var res = await http.post(
            Uri.parse(ApisConnect.signupApi),
            body: 
            {
              "name": name.text,
              "phone": phone.text
            }
          );

          var response = jsonDecode(res.body);

          if (response["success"] == true) 
          {
            Fluttertoast.showToast(msg: 'You Are signed up successfully. Login Now');
          } 
          else if (response["success"] == false) 
          {
            Fluttertoast.showToast(msg: 'Maybe Had Error');
          }

        }


      } 
      catch (e) 
      {
        Fluttertoast.showToast(msg: 'Error $e');
      }
    }
    else
    {
      Fluttertoast.showToast(msg: 'Fill All Fields');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,

        children: 
        [

          MainLogo(),

          SizedBox(height: FSizes.btwSections),

          MainInput(secure: false, controller: name, text: S.of(context).name),

          SizedBox(height: FSizes.btwInputs),

          InternationalPhoneNumberInput(controller: phone),

          SizedBox(height: FSizes.btwSections),

          ElevatedButton(
            onPressed: (){
              SignupClient();
            }, 
            child: Text(
              S.of(context).sign,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: FSizes.smallFont
              )
            )  
          ),

          SizedBox(height: FSizes.btwInputs),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,

            children: [
              Text(
                S.of(context).account
              ),

              TextButton(
                onPressed: ()=> Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginScreen())), 
                child: Text(
                  S.of(context).login
                ) 
              ),
            ],
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,

            children: [
              Text(
                S.of(context).tour
              ),

              TextButton(
                onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeUnUsers())),
                child: Text(
                  S.of(context).go
                ) 
              ),
            ],
          )

        ]
      ),
    );
  }
}