import 'package:help_me/constant/APIs.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/card.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class RefusedPostsScreen extends StatefulWidget {

  final String userID;

  const RefusedPostsScreen({
    super.key, 
    required this.userID
  });

  @override
  State<RefusedPostsScreen> createState() => _RefusedPostsScreenState();
}

class _RefusedPostsScreenState extends State<RefusedPostsScreen> {

  List<Map<String, dynamic>> postsdata = [];

  Future<void> getDeclinededPosts() async
  {
    try 
    {
      final response = await http.post(
        Uri.parse(ApisConnect.declinedPosts),
        body: {'client': widget.userID},
      );

      setState(() {

        postsdata = (jsonDecode(response.body) as List).map((item) => Map<String, dynamic>.from(item)).toList();

      });
    } 
    catch (e) 
    {
      Fluttertoast.showToast(msg: 'Error: $e');  
    }
  }

  @override
  void initState(){
    super.initState();
    getDeclinededPosts();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: SingleChildScrollView(
          child: 
          Column(
            children: [

              SizedBox(height: FSizes.btwInputs),
              
              MainLogo(),

              SizedBox(height: FSizes.btwSections),

              Column(
                children: postsdata.map((post) => 
                
                  MediumDeleteCard(
                    advID: '${post["post_id"]}',
                    imageUrl: '${ApisConnect.postPhoto}${post["image"]}',
                    title: '${post["name"]}',
                    location: '${post["state"]}, ${post["country"]}',
                    type: '${post["type"]}',
                    description: '${post["description"]}',
                    gender: '${post["gender"]}',
                    address: '${post["address"]} \n ${post["city"]}',
                    date: '${post["date"]}',
                    client: '${widget.userID}',
                  ),
                
                ).toList()
              ),

              SizedBox(height: FSizes.btwInputs),


            ]
          )
        )
      )
    );
  }
}