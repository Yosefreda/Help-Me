import 'package:help_me/constant/APIs.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class DetailsPostScreen extends StatefulWidget {

  final String postName;
  final String postType;
  final String postGender;
  final String postDescription;
  final String postImage;
  final String postOwner;
  final String postLocation;
  final String postAddress;

  const DetailsPostScreen({
    super.key,
    required this.postName,
    required this.postType,
    required this.postGender,
    required this.postDescription,
    required this.postImage,
    required this.postOwner,
    required this.postAddress,
    required this.postLocation    
  });

  @override
  State<DetailsPostScreen> createState() => _DetailsPostScreenState();
}

class _DetailsPostScreenState extends State<DetailsPostScreen> {

  String? PhoneNumberClient;


  Future<void> getPhoneNumber() async
  {
    try 
    {
      var getterPhone = await http.post(

        Uri.parse(ApisConnect.getPhoneNumberClient),
        body: {
          "id" : widget.postOwner
        }

      );

      var response = jsonDecode(getterPhone.body);

      setState(() {
        PhoneNumberClient = response["phone"];
      });
      
    } 
    catch (e) 
    {
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    getPhoneNumber();
  }

  @override
  Widget build(BuildContext context) {

    final mediaQuery = MediaQuery.of(context);
    final screenWidth = mediaQuery.size.width;

    return Scaffold(

      appBar: AppBar(),
      
      body: SingleChildScrollView(
        
        child: Column(
          
          children: [
        
            Image.network(
              widget.postImage
            ),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
              child: Divider(color: Colors.black)
            ),
        
            SizedBox(height: FSizes.btwInputs),

            Center(
              child: Text(
                widget.postGender == 'Missed' ? S.of(context).missed : S.of(context).found,
                style: TextStyle(
                  fontSize: FSizes.bigFont,
                  fontWeight: FontWeight.bold,
                  color: widget.postGender == 'Missed' ? Color.fromARGB(255, 230, 23, 8) : Colors.green
                )
              )
            ),

            SizedBox(height: FSizes.btwInputs),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.08),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    S.of(context).thing_name,
                    style: TextStyle(
                      fontSize: FSizes.smallFont,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                  Text(
                    widget.postName,
                    style: TextStyle(
                      fontSize: FSizes.medFont,
                      fontWeight: FontWeight.bold
                    )
                  )
                ]
              )
            ),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.08),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    S.of(context).thing_type,
                    style: TextStyle(
                      fontSize: FSizes.smallFont,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                  Text(
                    widget.postType == "Person" ? S.of(context).person : 
                    widget.postType == "Car" ? S.of(context).car:
                    widget.postType == "Electronic" ? S.of(context).electronic:
                    widget.postType == "Key" ? S.of(context).key:
                    widget.postType == "Watch" ? S.of(context).watch:
                    widget.postType == "Jewellry" ? S.of(context).jewellry:
                    widget.postType == "Document" ? S.of(context).document:
                    widget.postType == "Other" ? S.of(context).other: widget.postType,
                    style: TextStyle(
                      fontSize: FSizes.medFont,
                      fontWeight: FontWeight.bold
                    )
                  )
                ]
              )
            ),

            Center(
              child: Text(
                '${widget.postAddress} \n ${widget.postLocation}',
                style: TextStyle(
                  fontSize: FSizes.smallFont,
                  fontWeight: FontWeight.bold
                )
              )
            ),
      
            SizedBox(height: FSizes.btwInputs),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.08),
              child: Row(
                children: [
                  Text(
                    S.of(context).description,
                    style: TextStyle(
                      fontSize: FSizes.smallFont,
                      fontWeight: FontWeight.bold
                    )
                  )
                ]
              )
            ),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.15),
              child: Column(
                children: [
                  Text(
                    widget.postDescription,
                    style: TextStyle(
                      fontSize: FSizes.smallFont,
                      fontWeight: FontWeight.bold
                    )
                  )
                ]
              )
            ),
        
        
          ]
        )
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final Uri url = Uri(
            scheme: 'tel',
            path: '${PhoneNumberClient}'
          );

          if (await canLaunchUrl(url)) 
          {
            await launchUrl(url);  
          }
          else
          {
            Fluttertoast.showToast(msg: 'Error in phone data');
          }
        },
        child: Icon(Icons.phone)
      )

    );
  }
}
