import 'dart:convert';
import 'dart:async';
import 'package:help_me/constant/APIs.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:help_me/posts/filter.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/constant/card.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class PostsScreen extends StatefulWidget {
  const PostsScreen({super.key});

  @override
  State<PostsScreen> createState() => _PostsScreenState();
}

class _PostsScreenState extends State<PostsScreen> {

  TextEditingController search = TextEditingController();

  List<Map<String, dynamic>> postsdata = [];
  
  Future<void> getPostData() async 
  {
    try 
    {
      var response = await http.get(Uri.parse(ApisConnect.postsApi));

      setState(() {

        postsdata = (jsonDecode(response.body) as List).map( (item) => Map<String, dynamic>.from(item) ).toList();

      });

    } 
    catch (e) 
    {
      Fluttertoast.showToast(msg: 'Error: $e');  
    }
  }

  @override
  void initState(){
    super.initState();
    getPostData();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(),

      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          
          children: 
          [
            MainLogo(),
        
            SizedBox(height: FSizes.btwSections),
        
            SearchInput(controller: search),
        
            SizedBox(height: FSizes.btwInputs),

            Container(
              width: MediaQuery.of(context).size.width * 0.3,
              child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => FilterScreen()));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.filter_alt),
                
                    SizedBox(width: 5),
                
                    Text(
                      S.of(context).filter,
                      style: TextStyle(
                        fontSize: FSizes.smallFont,
                        fontWeight: FontWeight.bold
                      )
                    )
                  ]
                ),
              ),
            ),
        
            SizedBox(height: FSizes.btwInputs),
        
            Column(
              children: postsdata.map((post) => 
              
                MediumCard(
                  imageUrl: '${ApisConnect.postPhoto}${post["image"]}',
                  title: '${post["name"]}',
                  location: '${post["state"]} ,${post["country"]}',
                  type: '${post["type"]}',
                  description: '${post["description"]}',
                  gender: '${post["gender"]}',
                  address: '${post["address"]} \n ${post["city"]}',
                  date: '${post["date"]}',
                  client: '${post["client"].toString()}'
                ),
              
              ).toList()
            ),

            SizedBox(height: FSizes.btwSections),            


          ]
        )
      )
    );
  }
}


