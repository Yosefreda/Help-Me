import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:help_me/posts/activatedPosts.dart';
import 'package:help_me/posts/refusedPosts.dart';

class MyPostsScreen extends StatefulWidget {

  final String userID;

  const MyPostsScreen({
    super.key,
    required this.userID
  });

  @override
  State<MyPostsScreen> createState() => _MyPostsScreenState();
}

class _MyPostsScreenState extends State<MyPostsScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          bottom: TabBar(
            tabs: [
              Tab(
                icon: Text(
                  S.of(context).published,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),

              Tab(
                icon: Text(
                  S.of(context).refused,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),

        body: TabBarView(
          children: [
            // 1st Tab
            ActivatedPostsScreen(userID: widget.userID),

            // 2rd Tab
            RefusedPostsScreen(userID: widget.userID),
          ]
        )
      )
    );
  }
}
