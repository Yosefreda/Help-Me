import 'dart:io';

import 'package:help_me/constant/APIs.dart';
import 'package:help_me/posts/myPosts.dart';
import 'package:flutter/material.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:country_state_city_pro/country_state_city_pro.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/colors.dart';
import 'package:help_me/constant/inputs.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;


class ThingUploadScreen extends StatefulWidget {

  final String userID;

  const ThingUploadScreen({
    super.key,
    required this.userID
  });

  @override
  State<ThingUploadScreen> createState() => _ThingUploadScreenState();
}

class _ThingUploadScreenState extends State<ThingUploadScreen> {

  String? selectedTypes;
  String? selectedGender;
  File? imagePath;
  String? imageName;
  String? imageData;


  List<String> get gender {
  return [
    S.of(context).or,
    S.of(context).missed,
    S.of(context).found,
  ];
  }

  List<String> get types {
  return [
    S.of(context).select,
    S.of(context).person,
    S.of(context).car,
    S.of(context).electronic,
    S.of(context).key,
    S.of(context).watch,
    S.of(context).jewellry,
    S.of(context).document,
    S.of(context).other
  ];
  }

  TextEditingController name = TextEditingController();
  TextEditingController description = TextEditingController();
  TextEditingController location = TextEditingController();
  TextEditingController date = TextEditingController();
  TextEditingController countryCont = TextEditingController(); 
  TextEditingController stateCont = TextEditingController(); 
  TextEditingController cityCont = TextEditingController();
  ImagePicker imagePicker = ImagePicker();


  Future<void> getImage() async
  {
    var getimage = await imagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      imagePath = File(getimage!.path);
      imageName = getimage.path.split('/').last;
      imageData = base64Encode(imagePath!.readAsBytesSync());
      print(imagePath);
      print(imageName);
      print(imageData);
    });

  }


  Future<void> addPost() async {
    if (name.text.isNotEmpty) {
      try {
        var uri = Uri.parse(ApisConnect.addPostApi);
        var request = http.MultipartRequest('POST', uri)
          ..fields['photo_name'] = imageName ?? ''
          ..fields['name'] = name.text
          ..fields['type'] = selectedTypes ?? ''
          ..fields['description'] = description.text
          ..fields['country'] = countryCont.text
          ..fields['state'] = stateCont.text
          ..fields['city'] = cityCont.text
          ..fields['location'] = location.text
          ..fields['date'] = date.text
          ..fields['gender'] = selectedGender ?? ''
          ..fields['client'] = widget.userID;

        if (imageData != null && imageData is List<int>) {
          request.files.add(http.MultipartFile.fromBytes('photo_data', imageData as List<int>));
        }

        var response = await request.send();

        if (response.statusCode == 200) {
          var responseData = await response.stream.bytesToString();
          var decodedResponse = jsonDecode(responseData);

          if (decodedResponse["posted"] == true) {
            Fluttertoast.showToast(msg: 'The Post Added Successfully');
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => MyPostsScreen(userID: widget.userID)),
            );
          } else {
            Fluttertoast.showToast(msg: 'There may have been an error');
          }
        } 
        else 
        {
          Fluttertoast.showToast(msg: 'Failed to add post. Status code: ${response.statusCode}');
        }
      } catch (e) {
        Fluttertoast.showToast(msg: 'Error: ${e.toString()}');
      }
    } 
    else 
    {
      Fluttertoast.showToast(msg: 'Please fill all fields');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(),
      
      body: SingleChildScrollView(

        child: Column(
        
          children: 
          [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: 
              [
                Text(
                  S.of(context).upload,
                  style: TextStyle(
                    fontSize: FSizes.medFont,
                    fontWeight: FontWeight.w600
                  )
                ),
                
                Text(
                  S.of(context).post,
                  style: TextStyle(
                    fontSize: FSizes.medFont,
                    fontWeight: FontWeight.w900,
                    color: FColors.primary
                  )
                )
              ]
            ),

            SizedBox(height: 40),

            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: DropdownButtonFormField(

                value: gender.first,
                icon: const Icon(Icons.keyboard_arrow_down),
                items: gender.map((String items2) {
                  return DropdownMenuItem(
                    value: items2,
                    child: Text(items2),
                  );
                }).toList(),
                onChanged: (String? newValue2) {
                  setState(() {
                    selectedGender = newValue2;
                  });
                },
              ),
            ),

            SizedBox(height: FSizes.btwInputs),

            MainInput(secure: false, text: S.of(context).name, controller: name),

            SizedBox(height: FSizes.btwInputs),

            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),

              child: DropdownButtonFormField(

                value: types.first,
                icon: const Icon(Icons.keyboard_arrow_down),
                items: types.map((String items2) {
                  return DropdownMenuItem(
                    value: items2,
                    child: Text(items2),
                  );
                }).toList(),
                onChanged: (String? newValue2) {
                  setState(() {
                    selectedTypes = newValue2;
                  });
                },
              ),
            ),
        
            SizedBox(height: FSizes.btwInputs),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: TextField(
                style: TextStyle(
                  height: 6
                ),
                decoration: InputDecoration(
                  hintText: S.of(context).description
                ),
                controller: description
              ),
            ),
        
            SizedBox(height: FSizes.btwInputs),
        
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: CountryStateCityPicker( 
                country: countryCont, 
                state: stateCont, 
                city: cityCont,
                dialogColor: Colors.grey.shade200, 
                textFieldDecoration: InputDecoration()
              ),
            ),

            SizedBox(height: FSizes.btwInputs),
        
            MainInput(secure: false, text: S.of(context).location, controller: location),

            SizedBox(height: FSizes.btwInputs),

            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: TextField(
                controller: date,
                decoration: InputDecoration(
                  labelText: S.of(context).date,
                  prefixIcon: Icon(Icons.calendar_today)
                ),
                readOnly: true,
                onTap: () async {
                  final selectedDate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime.now(),
                  );

                  if (selectedDate != null) {
                    final dateOnly = DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
                    print('${selectedDate.toString()}');
                    date.text = DateFormat.yMd().format(dateOnly);
                  }
                }
              )
            ),

            SizedBox(height: FSizes.btwInputs),
            SizedBox(height: FSizes.btwInputs),

            Center(
              child: TextButton(
                style: TextButton.styleFrom(
                  side:  BorderSide(width: 1),
                  fixedSize:  Size(150, 50)
                ),
                onPressed: () {
                  getImage();
                },
                child:  Text(
                  'Upload Photo',
                  style: TextStyle(
                    color: Colors.black
                  ),
                ),
              ),
            ),

            SizedBox(height: FSizes.btwInputs),

            imagePath != null ? Image.file(imagePath!) : Text('No Photo Chosen'),


            SizedBox(height: FSizes.btwInputs),
            SizedBox(height: FSizes.btwSections),

            ElevatedButton(
              onPressed: (){
                addPost();
              }, 
              style: ButtonStyle(
                fixedSize: WidgetStateProperty.resolveWith((states){
                  return Size(185, 60);
                })            
              ),
              child: Text(
                S.of(context).submit,
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold
                )
              )
            ),

            SizedBox(height: FSizes.btwSections),
        
          ]
        )
      )
    );
  }
}