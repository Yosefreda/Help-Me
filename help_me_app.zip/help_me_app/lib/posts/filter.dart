import 'package:country_state_city_pro/country_state_city_pro.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';

class FilterScreen extends StatefulWidget {
  const FilterScreen({super.key});

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {

  final TextEditingController countryCont = TextEditingController(); 
  final TextEditingController stateCont = TextEditingController(); 
  final TextEditingController cityCont = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          S.of(context).filter,
          style: TextStyle(
            fontWeight: FontWeight.bold
          )
        )
      ),

      body: SingleChildScrollView(
        child: Column(
          children: 
          [
            SizedBox(height: FSizes.btwInputs),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Text(
                  S.of(context).type,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                ),

                SizedBox(height: FSizes.btwInputs),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: 
                  [
                    InkWell(
                      onTap: () {},
                      child: Column(
                        children: [
                          CircleAvatar(
                            child: ClipOval(
                              child: Icon(Icons.arrow_downward)
                            )
                          ),

                          Text(
                            S.of(context).missed
                          )
                        ]
                      )
                    ),

                    SizedBox(width: FSizes.btwSections),
                    
                    InkWell(
                      onTap: () {},
                      child: Column(
                        children: [
                          CircleAvatar(
                            child: ClipOval(
                              child: Icon(Icons.arrow_upward)
                            )
                          ),
                          
                          Text(
                            S.of(context).found
                          )
                        ]
                      )
                    ),

                  ]
                ),

                SizedBox(height: 20),
              
                Divider(),

                SizedBox(height: FSizes.btwInputs),

                Text(
                  S.of(context).location,
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  )
                ),

                Container(
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  child: CountryStateCityPicker( 
                    country: countryCont, 
                    state: stateCont, 
                    city: cityCont, 
                    dialogColor: Colors.grey.shade200, 
                    textFieldDecoration: InputDecoration()
                  )
                ),

                SizedBox(height: FSizes.btwInputs),

                ElevatedButton(
                  onPressed: (){}, 
                  child: Text(S.of(context).see)
                )

              
              ]
            ) 
          ]
        )
      )
    );
  }
}