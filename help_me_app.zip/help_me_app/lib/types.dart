import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/constant/buttons.dart';

class TypesScreen extends StatefulWidget {
  const TypesScreen({super.key});

  @override
  State<TypesScreen> createState() => _TypesScreenState();
}

class _TypesScreenState extends State<TypesScreen> {

  TextEditingController search = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: SmallLogo(),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: 
          [
            SearchInput(controller: search),
        
            SizedBox(height: FSizes.btwSections),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.summarize), text: S.of(context).all),

            Typebutton(onPressed: (){},icon: Icon(Icons.person_3), text: S.of(context).person),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.car_repair), text: S.of(context).car),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.devices_other), text: S.of(context).electronic),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.key), text: S.of(context).key),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.watch), text: S.of(context).watch),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.diamond), text: S.of(context).jewellry),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.document_scanner), text: S.of(context).document),
        
            Typebutton(onPressed: (){},icon: Icon(Icons.forward), text: S.of(context).other),
        
          ]
        ),
      )
    );
  }
}