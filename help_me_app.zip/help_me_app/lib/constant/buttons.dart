import 'package:flutter/material.dart';
import 'package:help_me/constant/sizes.dart';


class Typebutton extends StatelessWidget {
  const Typebutton({super.key, required this.icon, required this.text, this.onPressed});

  final Icon icon;
  final String text;
  final onPressed;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 10),
          child: Align(
            alignment: Alignment.center,
            child: SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: onPressed, 
                icon: icon,
                label: Text(
                  text,
                  style: TextStyle(
                    fontSize: FSizes.smallFont,
                  ),
                ),
                style: TextButton.styleFrom(
                  alignment: Alignment.centerLeft,
                ),
              ),
            ),
          ),
        ),
        Divider()
      ]
    );
  }
}

class SettingsButtons extends StatelessWidget {
  const SettingsButtons({super.key, required this.icon, required this.text, this.onPressed});

  final Icon icon;
  final String text;
  final onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      child: Align(
        alignment: Alignment.center,
        child: SizedBox(
          width: double.infinity,
          child: TextButton.icon(
            onPressed: onPressed, 
            icon: icon,
            label: Text(
              text,
              style: TextStyle(
                fontSize: FSizes.smallFont,
              ),
            ),
            style: TextButton.styleFrom(
              alignment: Alignment.centerLeft,
            ),
          ),
        ),
      ),
    );
  }
}