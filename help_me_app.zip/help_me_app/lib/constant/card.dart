import 'package:help_me/unuser/postDetailsUnuser.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/colors.dart';
import 'package:help_me/posts/postDetails.dart';
import 'package:help_me/posts/myPostDetails.dart';

class MediumCard extends StatefulWidget {
  final String imageUrl;
  final String title;
  final String description;
  final String type;
  final String location;
  final String gender;
  final String address;
  final String date;
  final String client;

  const MediumCard({
    super.key,
    required this.imageUrl,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    required this.gender,
    required this.address,
    required this.date,
    required this.client,
  });

  @override
  _MediumCardState createState() => _MediumCardState();
}

class _MediumCardState extends State<MediumCard> {

  void Header(BuildContext)
  {
    Navigator.push(context, MaterialPageRoute(builder: (context) => DetailsPostScreen(
      postName: widget.title,
      postGender: widget.gender,
      postType: widget.type,
      postDescription: widget.description,
      postOwner: widget.client,
      postImage: widget.imageUrl,
      postAddress: widget.address,
      postLocation: widget.location,
    )
    ));  
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10),
          child: InkWell(
            onTap: () {
              Header(BuildContext);
            },
            child: Card(
              elevation: 4.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(10.0)),
                    child: Image.network(
                      widget.imageUrl,
                      height: constraints.maxWidth * 0.5,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.title,
                          style: TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          widget.description,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                        SizedBox(height: 15),
                        Row(
                          children: [
                            Icon(
                              Icons.type_specimen,
                              color: FColors.primary,
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.type,
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Row(
                          children: [
                            Icon(
                              Icons.location_on,
                              color: FColors.primary,
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.location,
                                style: TextStyle(
                                  fontSize: 18.0,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: () {
                              Header(BuildContext);
                            },
                            child: Icon(Icons.arrow_forward_ios),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}


class MediumUnuserCard extends StatefulWidget {
  final String imageUrl;
  final String title;
  final String description;
  final String type;
  final String location;
  final String gender;
  final String address;
  final String date;
  final String client;

  MediumUnuserCard({
    super.key,
    required this.imageUrl,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    required this.gender,
    required this.address,
    required this.date,
    required this.client
  });

  @override
  _MediumUnuserCardState createState() => _MediumUnuserCardState();
}

class _MediumUnuserCardState extends State<MediumUnuserCard> {

  void Header(BuildContext)
  {
    Navigator.push(context, MaterialPageRoute(builder: (context) => DetailsPostUnuserScreen(
      postName: widget.title,
      postGender: widget.gender,
      postType: widget.type,
      postDescription: widget.description,
      postOwner: widget.client,
      postImage: widget.imageUrl,
      postAddress: widget.address,
      postLocation: widget.location,
    )
    ));  
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10),
          child: InkWell(
            onTap: () {
              Header(BuildContext);
            },
            child: Card(
              elevation: 4.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(10.0)),
                    child: Image.network(
                      widget.imageUrl,
                      height: constraints.maxWidth * 0.5,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.title,
                          style: TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          widget.description,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                        SizedBox(height: 15),
                        Row(
                          children: [
                            Icon(
                              Icons.type_specimen,
                              color: FColors.primary,
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.type,
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.grey[600],
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 10),
                        Row(
                          children: [
                            Icon(
                              Icons.location_on,
                              color: FColors.primary,
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.location,
                                style: TextStyle(
                                  fontSize: 18.0,
                                  color: Colors.grey[600],
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 10),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: () {
                             Header(BuildContext);
                            },
                            child: Icon(Icons.arrow_forward_ios),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}


class MediumDeleteCard extends StatefulWidget {
  final String advID;
  final String imageUrl;
  final String title;
  final String description;
  final String type;
  final String location;
  final String gender;
  final String address;
  final String date;
  final String client;

  MediumDeleteCard({
    required this.advID,
    required this.imageUrl,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    required this.gender,
    required this.address,
    required this.date,
    required this.client
  });

  @override
  _MediumDeleteCardState createState() => _MediumDeleteCardState();
}

class _MediumDeleteCardState extends State<MediumDeleteCard> {

  void Header(BuildContext)
  {
    Navigator.push(context, MaterialPageRoute(builder: (context) => DetailsMyPostScreen(
      postNumber: widget.advID,
      postName: widget.title,
      postGender: widget.gender,
      postType: widget.type,
      postDescription: widget.description,
      postOwner: widget.client,
      postImage: widget.imageUrl,
      postAddress: widget.address,
      postLocation: widget.location, 
      userID: widget.client, 
    )
    ));  
  }
  
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10),
          child: InkWell(
            onTap: () {
              Header(BuildContext);
            },
            child: Card(
              elevation: 4.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(10.0)),
                    child: Image.network(
                      widget.imageUrl,
                      height: constraints.maxWidth * 0.5,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.title,
                          style: TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          widget.description,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                        SizedBox(height: 15),
                        Row(
                          children: [
                            Icon(
                              Icons.type_specimen,
                              color: FColors.primary,
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.type,
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Row(
                          children: [
                            Icon(
                              Icons.location_on,
                              color: FColors.primary,
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.location,
                                style: TextStyle(
                                  fontSize: 18.0,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: () {
                              Header(BuildContext);
                            },
                            child: Icon(Icons.arrow_forward_ios)
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
