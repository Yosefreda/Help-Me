import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:help_me/constant/colors.dart';

class MainLogo extends StatelessWidget {
  const MainLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        
        double width = constraints.maxWidth;

        double medFontSize = width > 600 ? 16 : width < 1200 ? 24 : 32;
        double smallFontSize = width > 600 ? 12 : width < 1200 ? 16 : 20;

        return Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.settings_input_antenna_rounded,
                  color: Colors.blue,
                  size: 50,
                ),

                SizedBox(width: 5),

                Text(
                  S.of(context).logo,
                  style: TextStyle(
                    color: FColors.primary,
                    fontSize: medFontSize,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  S.of(context).company,
                  style: TextStyle(
                    fontSize: smallFontSize,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class SmallLogo extends StatelessWidget {
  const SmallLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        double width = constraints.maxWidth;

        double smallFontSize = width > 600 ? 12 : width < 1200 ? 16 : 20;

        return Container(
          margin: EdgeInsets.only(right: 55),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.settings_input_antenna_rounded,
                color: Colors.blue,
                size: 30,
              ),

              SizedBox(width: 5),

              Text(
                S.of(context).logo,
                style: TextStyle(
                  color: FColors.primary,
                  fontSize: smallFontSize,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

