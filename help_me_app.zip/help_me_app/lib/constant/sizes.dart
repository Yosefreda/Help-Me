class FSizes
{
  static const double btwInputs = 30;
  static const double btwTypes = 30;
  static const double btwTypes2 = 20;
  static const double btwSections = 60;

  static const double smallFont = 20;
  static const double medFont = 30;
  static const double bigFont = 45;
}