
import 'package:flutter/material.dart';

class FColors
{
  static const Color primary = Color.fromARGB(255, 12, 97, 21);
}