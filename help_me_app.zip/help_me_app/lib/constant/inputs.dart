import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field2/intl_phone_field.dart';

class MainInput extends StatelessWidget {
  const MainInput({super.key, required this.secure, required this.text,  required this.controller});

  final bool secure;
  final controller;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      child: TextField(
        obscureText: secure,
        decoration: InputDecoration(
          hintText: text
        ),
        controller: controller,
      )
    );
  }
}

class SearchInput extends StatelessWidget {
  const SearchInput({super.key,required this.controller});

  final controller;

  @override
  Widget build(BuildContext context) {
    return             
    Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                hintText: S.of(context).search
              )
            )
          ),
      
      
          TextButton(
            onPressed: (){}, 
            child: Icon(Icons.search)
          )
        ]
      )
    );
  }
}

class InternationalPhoneNumberInput extends StatelessWidget {
  const InternationalPhoneNumberInput({super.key, required this.controller});

  final controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      child: IntlPhoneField(
        decoration: InputDecoration(
          labelText: S.of(context).phone,
        ),
        initialCountryCode: 'EG',
        onChanged: (phone) {
          controller.text = phone.completeNumber;
        },
      ),
    );
  }
}
