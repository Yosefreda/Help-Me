class ApisConnect
{
  static const String MainApi = "http://10.0.2.2:8080/dashboard/help_me/APIs";

  /// VALIDATE & UPDATE PHONE NUMBER ///
  static const String checkPhoneNumberApi = "$MainApi/ValidatePhone.php";
  static const String updatePhoneNumberApi = "$MainApi/updatePhone.php";

  /// FOR SIGN UP CLIENT ///
  static const String signupApi = "$MainApi/signup.php";

  ///// FOR LOGIN /////
  static const String loginApi = "$MainApi/login.php";

  ///// FOR ADD NEW POST /////
  static const String addPostApi = "$MainApi/addPost.php";

  ///// POST API LINK /////
  static const String postsApi = "$MainApi/posts.php";
  static const String postPhoto = "$MainApi/photos/";

  //// GET PHONE CLIENT FOR POST ////
  static const String getPhoneNumberClient = "$MainApi/getPhoneNumber.php";

  ///// MY POSTS LINK //////
  static const String activatedPosts = "$MainApi/postsActivated.php";
  static const String declinedPosts = "$MainApi/postsDeclined.php";

  ///// DELETE POST LINK /////
  static const String deletePostApi = "$MainApi/deletePost.php";

  ///// SUGGGESSTION & PROBLEM DATA /////
  static const String problemInsert = "$MainApi/insertProblem.php";

}