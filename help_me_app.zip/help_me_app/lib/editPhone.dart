import 'package:help_me/constant/APIs.dart';
import 'package:help_me/constant/inputs.dart';
import 'package:help_me/constant/logos.dart';
import 'package:help_me/constant/sizes.dart';
import 'package:help_me/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class EditPhoneNumberScreen extends StatefulWidget {

  final String userID;

  const EditPhoneNumberScreen({
    super.key, 
    required this.userID
  });

  @override
  State<EditPhoneNumberScreen> createState() => _EditPhoneNumberScreenState();
}

class _EditPhoneNumberScreenState extends State<EditPhoneNumberScreen> {

  TextEditingController NewPhone = TextEditingController();

  Future<void> updatePhoneNumber() async
  {
    if (NewPhone.text.isNotEmpty) 
    {
      try 
      {
        var res = await http.post(
          Uri.parse(ApisConnect.checkPhoneNumberApi),
          body: {
            "phone" : NewPhone.text,
          },
        );

        var response1 = jsonDecode(res.body);

        if (response1["exists"] == true) 
        {
          Fluttertoast.showToast(msg: 'This Phone Already exists');
        }
        else
        {
          var upgrade = await http.post(
            Uri.parse(ApisConnect.updatePhoneNumberApi),
            body: {
              "phone" : NewPhone.text,
              "client" : widget.userID
            }
          );

          var response2 = jsonDecode(upgrade.body);

          if (response2["update"] == true) 
          {
            Fluttertoast.showToast(msg: 'Your Phone Updated Successfully');
          } 
          else
          {
            Fluttertoast.showToast(msg: 'May be had error, Please try again');
          }
        }

      } 
      catch (e) 
      {
        Fluttertoast.showToast(msg: 'Error: $e');  
      }      
    } 
    else
    {
      Fluttertoast.showToast(msg: 'Fill All Fields');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,

        children: 
        [

          SizedBox(height: FSizes.btwSections),
          SizedBox(height: FSizes.btwSections),

          MainLogo(),

          SizedBox(height: FSizes.btwSections),

          Text(
            S.of(context).Edit_Phone_Number,
            style: TextStyle(
              fontSize: FSizes.medFont,
              fontWeight: FontWeight.bold
            )
          ),

          SizedBox(height: FSizes.btwSections),

          InternationalPhoneNumberInput(controller: NewPhone),
 
          SizedBox(height: FSizes.btwSections),

          ElevatedButton(
            onPressed: (){
              updatePhoneNumber();
            }, 
            style: ButtonStyle(
              fixedSize: MaterialStateProperty.resolveWith((states){
                return Size(175, 60);
              })            
            ),
            child: Text(
              S.of(context).submit,
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold
              )
            )
          )

        ]
      )
    );
  }
}